--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (1, 'Domingo', 19, 22, 88, 'Chuvas Intensas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (2, 'Segunda-Feira', 20, 17, 68, 'Chuvas Intensas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (3, 'Terça-Feira', 26, 18, 24, 'Chuvas Isoladas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (4, 'Quarta-Feira', 26, 17, 27, 'Chuvas Isoladas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (5, 'Quinta-Feira', 27, 19, 13, 'Chuvas Isoladas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (6, 'Sexta-Feira', 26, 17, 9, 'Chuvas Isoladas');
--insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, descricao) values (7, 'Sábado', 22, 19, 30, 'Chuvas Isoladas');
insert into usuario (id, login, senha) values (1, 'usuario', 'senha')